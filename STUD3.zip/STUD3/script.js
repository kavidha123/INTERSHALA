
// Wait for the DOM to fully load before executing scripts
document.addEventListener('DOMContentLoaded', () => {
    const studentForm = document.getElementById('studentForm');
    const studentsTableBody = document.querySelector('#studentsTable tbody');
    // Retrieve student data from local storage or initialize an empty array
    let students = JSON.parse(localStorage.getItem('students')) || [];

    // Function to display all students in the table
    const displayStudents = () => {
        // Clear the table body before displaying updated records
        studentsTableBody.innerHTML = '';
        // Loop through the students array and create a table row for each student
        students.forEach((student, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${student.name}</td>
                <td>${student.id}</td>
                <td>${student.email}</td>
                <td>${student.contact}</td>
                <td class="actions">
                    <button onclick="editStudent(${index})">Edit</button>
                    <button class="delete" onclick="deleteStudent(${index})">Delete</button>
                </td>
            `;
            // Append the row to the table body
            studentsTableBody.appendChild(row);
        });
    };

    // Function to add a new student
    const addStudent = (e) => {
        e.preventDefault(); // Prevent form submission
        // Get input values from the form
        const name = studentForm.studentName.value.trim();
        const id = studentForm.studentID.value.trim();
        const email = studentForm.email.value.trim();
        const contact = studentForm.contactNumber.value.trim();

        // Validate that all fields are filled
        if (name && id && email && contact) {
            // Push the new student object into the students array
            students.push({ name, id, email, contact });
            // Save the updated students array to local storage
            localStorage.setItem('students', JSON.stringify(students));
            // Reset the form after submission
            studentForm.reset();
            // Display the updated student list
            displayStudents();
        }
    };

    // Function to edit an existing student record
    window.editStudent = (index) => {
        const student = students[index];
        // Pre-fill the form with the student's current data
        studentForm.studentName.value = student.name;
        studentForm.studentID.value = student.id;
        studentForm.email.value = student.email;
        studentForm.contactNumber.value = student.contact;

        // Remove the student from the array and update local storage
        students.splice(index, 1);
        localStorage.setItem('students', JSON.stringify(students));
        // Display the updated student list
        displayStudents();
    };

    // Function to delete a student record
    window.deleteStudent = (index) => {
        // Remove the student from the array
        students.splice(index, 1);
        // Update local storage with the modified array
        localStorage.setItem('students', JSON.stringify(students));
        // Display the updated student list
        displayStudents();
    };

    // Add event listener for form submission
    studentForm.addEventListener('submit', addStudent);

    // Initial display of students when the page loads
    displayStudents();
});
